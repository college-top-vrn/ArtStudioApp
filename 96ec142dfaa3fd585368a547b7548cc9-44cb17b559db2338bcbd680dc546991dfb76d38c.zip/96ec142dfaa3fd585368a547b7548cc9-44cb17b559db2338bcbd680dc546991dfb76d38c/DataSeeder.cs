using System.Threading.Tasks;
using Microsoft.Data.Sqlite;

namespace CreativeStudio
{
    public static class DataSeeder
    {
        public static async Task SeedAsync(string connectionString)
        {
            using var connection = new SqliteConnection(connectionString);
            await connection.OpenAsync();

            // Включение проверки внешних ключей (важно для SQLite)
            using var pragma = new SqliteCommand("PRAGMA foreign_keys = ON;", connection);
            await pragma.ExecuteNonQueryAsync();

            // 1. Исполнители и их личные дела (1:1)
            var persons = new[]
            {
                ("alex_cool", "2023-01-15", "AB123456", "ул. Ленина, 1"),
                ("jane_edit", "2023-02-20", "CD789012", "пр. Мира, 10"),
                ("pete_director", "2023-03-10", "EF345678", "ул. Гагарина, 5")
            };

            foreach (var (nick, regDate, passport, addr) in persons)
            {
                // Вставка в Persons
                string insertPerson = "INSERT INTO Persons (Nickname, RegistrationDate) VALUES (@nick, @regDate); SELECT last_insert_rowid();";
                using var cmdPerson = new SqliteCommand(insertPerson, connection);
                cmdPerson.Parameters.AddWithValue("@nick", nick);
                cmdPerson.Parameters.AddWithValue("@regDate", regDate);
                long personId = (long)await cmdPerson.ExecuteScalarAsync();

                // Вставка в PrivateData
                string insertPrivate = "INSERT INTO PrivateData (PersonId, PassportData, Address) VALUES (@pid, @pass, @addr)";
                using var cmdPrivate = new SqliteCommand(insertPrivate, connection);
                cmdPrivate.Parameters.AddWithValue("@pid", personId);
                cmdPrivate.Parameters.AddWithValue("@pass", passport);
                cmdPrivate.Parameters.AddWithValue("@addr", addr);
                await cmdPrivate.ExecuteNonQueryAsync();
            }

            // 2. Проекты
            var projects = new[] { ("Короткометражный фильм", "2025-12-01"), ("Рекламный ролик", "2025-10-15") };
            foreach (var (name, deadline) in projects)
            {
                string insertProject = "INSERT INTO Projects (Name, Deadline) VALUES (@name, @deadline)";
                using var cmdProject = new SqliteCommand(insertProject, connection);
                cmdProject.Parameters.AddWithValue("@name", name);
                cmdProject.Parameters.AddWithValue("@deadline", deadline);
                await cmdProject.ExecuteNonQueryAsync();
            }

            // 3. Связи M:N с ролями (получаем ID исполнителей и проектов)
            // Получаем ID по псевдонимам
            var personIds = new System.Collections.Generic.Dictionary<string, long>();
            using (var cmd = new SqliteCommand("SELECT Id, Nickname FROM Persons", connection))
            using (var reader = await cmd.ExecuteReaderAsync())
            {
                while (await reader.ReadAsync())
                    personIds[reader.GetString(1)] = reader.GetInt64(0);
            }

            var projectIds = new System.Collections.Generic.Dictionary<string, long>();
            using (var cmd = new SqliteCommand("SELECT Id, Name FROM Projects", connection))
            using (var reader = await cmd.ExecuteReaderAsync())
            {
                while (await reader.ReadAsync())
                    projectIds[reader.GetString(1)] = reader.GetInt64(0);
            }

            // Назначение ролей
            var participations = new[]
            {
                (person: "alex_cool", project: "Короткометражный фильм", role: "Сценарист"),
                (person: "jane_edit", project: "Короткометражный фильм", role: "Монтажёр"),
                (person: "pete_director", project: "Короткометражный фильм", role: "Режиссёр"),
                (person: "alex_cool", project: "Рекламный ролик", role: "Оператор"),
                (person: "jane_edit", project: "Рекламный ролик", role: "Монтажёр")
            };

            foreach (var p in participations)
            {
                string insertParticipation = @"
                    INSERT INTO ProjectParticipations (PersonId, ProjectId, Role)
                    VALUES (@pid, @projid, @role)";
                using var cmd = new SqliteCommand(insertParticipation, connection);
                cmd.Parameters.AddWithValue("@pid", personIds[p.person]);
                cmd.Parameters.AddWithValue("@projid", projectIds[p.project]);
                cmd.Parameters.AddWithValue("@role", p.role);
                await cmd.ExecuteNonQueryAsync();
            }
        }
    }
}