using System.Threading.Tasks;
using Microsoft.Data.Sqlite;


namespace CreativeStudio
{
    public static class DatabaseManager
    {
        public static async Task InitializeAsync(string connectionString)
        {
            using var connection = new SqliteConnection(connectionString);
            await connection.OpenAsync();

            string createPerson = @"
                CREATE TABLE IF NOT EXISTS Person (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Nickname TEXT NOT NULL UNIQUE,
                    Registered TEXT NOT NULL,
                );";

            string createPrivateData = @"
                CREATE TABLE IF NOT EXISTS PrivateData (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    PersonId INTEGER NOT NULL UNIQUE,
                    Password TEXT NOT NULL,
                    Address TEXT NOT NULL,
                    FOREIGN KEY (PersonId) REFERENCES Person (PersonId) ON DELETE CASCADE,
                );";

            string createPrijects = @"
                CREATE TABLE IF NOT EXISTS PrivateData (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Name TEXT NOT NULL,
                    Description TEXT NOT NULL
                );";

            string createParticipations = @"
                CREATE TABLE IF NOT EXISTS PrivateData (
                    PersonId INTEGER NOT NULL,
                    Profile TEXT NOT NULL,
                    Role TEXT NOT NULL,
                    PRIMARY KEY (PersonId, Profile),
                    FOREIGN KEY (PersonId) REFERENCES Person Person(Id) ON DELETE CASCADE,
                    
                    FOREIGN KEY (PersonId) REFERENCES Person (Id) ON UPDATE CASCADE,
                );";
            
            using var cmd = new SqliteCommand(createPerson, connection);
            await cmd.ExecuteNonQueryAsync();
            cmd.CommandText = createPerson;
            await cmd.ExecuteNonQueryAsync();
            cmd.CommandText = createPrivateData;
            await cmd.ExecuteNonQueryAsync();
            cmd.CommandText = createPrijects;
            await cmd.ExecuteNonQueryAsync();

        }
    }
}

